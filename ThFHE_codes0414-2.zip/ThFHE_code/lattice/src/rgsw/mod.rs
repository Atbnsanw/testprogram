mod normal;
mod ntt;

pub use normal::Rgsw;
pub use ntt::NttRgsw;
