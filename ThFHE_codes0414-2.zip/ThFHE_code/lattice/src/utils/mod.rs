//! Defines some space type for pre-allocated.

mod space;

pub use space::*;
